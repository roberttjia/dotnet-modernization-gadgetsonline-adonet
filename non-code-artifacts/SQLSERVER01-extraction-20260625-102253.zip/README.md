# SQL Server Extraction Report

- **Hostname:** `SQLSERVER01:1433`
- **SQL Server:** SQL Server 2022 (Enterprise Edition (64-bit))
- **Version:** 16.0.1180.1 (RTM)
- **Collation:** SQL_Latin1_General_CP1_CI_AS
- **Clustered:** False
- **Always On:** False
- **Extracted:** 2026-06-25T10:22:53.7735030Z

## SQL Server Services Detection

| Service | Status | Details |
|---------|--------|---------|
| SSIS | [!] DETECTED | 8 legacy packages in msdb |
| SSRS | [ok] NOT_DETECTED | No evidence found |
| SSAS | [ok] NOT_DETECTED | No evidence found |

### Migration Advisory

- **SSIS:** SSIS packages will need to be migrated to an alternative ETL solution (e.g., AWS Glue).
- **SSAS Note:** SSAS runs as a separate service and may be installed without leaving detectable artifacts. Confirm with your server administrator.

See `server_profile.json` for full detection details.
## SQL Server Agent Jobs

1 job(s): 1 TSQL

## Service Broker

Enabled in: OtherDatabase01, OtherDatabase02, OtherDatabase03, GadgetsOnlineADO, OtherDatabase04, OtherDatabase05, OtherDatabase06, OtherDatabase07, OtherDatabase08, OtherDatabase09, OtherDatabase10, OtherDatabase11, OtherDatabase12, OtherDatabase13, OtherDatabase14, OtherDatabase15, OtherDatabase16, OtherDatabase17, OtherDatabase18, OtherDatabase19, OtherDatabase20, OtherDatabase21, OtherDatabase22, OtherDatabase23, OtherDatabase24, OtherDatabase25, OtherDatabase26, OtherDatabase27, OtherDatabase28, OtherDatabase29, OtherDatabase30

## Databases

- [GadgetsOnlineADO](./GadgetsOnlineADO/README.md)

