CREATE TABLE [dbo].[Carts] (
    [RecordId] INT IDENTITY(1,1) NOT NULL,
    [CartId] NVARCHAR(255) NOT NULL,
    [ProductId] INT NOT NULL,
    [Count] INT NOT NULL,
    [DateCreated] DATETIME NOT NULL
);
GO

CREATE TABLE [dbo].[Categories] (
    [CategoryId] INT IDENTITY(1,1) NOT NULL,
    [Name] NVARCHAR(255) NOT NULL,
    [Description] NVARCHAR(1024) NULL
);
GO

CREATE TABLE [dbo].[OrderDetails] (
    [OrderDetailId] INT IDENTITY(1,1) NOT NULL,
    [OrderId] INT NOT NULL,
    [ProductId] INT NOT NULL,
    [Quantity] INT NOT NULL,
    [UnitPrice] DECIMAL(18,2) NOT NULL
);
GO

CREATE TABLE [dbo].[Orders] (
    [OrderId] INT IDENTITY(1,1) NOT NULL,
    [OrderDate] DATETIME NOT NULL,
    [Username] NVARCHAR(255) NULL,
    [FirstName] NVARCHAR(160) NOT NULL,
    [LastName] NVARCHAR(160) NOT NULL,
    [Address] NVARCHAR(70) NOT NULL,
    [City] NVARCHAR(40) NOT NULL,
    [State] NVARCHAR(40) NOT NULL,
    [PostalCode] NVARCHAR(10) NOT NULL,
    [Country] NVARCHAR(40) NOT NULL,
    [Phone] NVARCHAR(24) NOT NULL,
    [Email] NVARCHAR(255) NOT NULL,
    [Total] DECIMAL(18,2) NOT NULL
);
GO

CREATE TABLE [dbo].[Products] (
    [ProductId] INT IDENTITY(1,1) NOT NULL,
    [CategoryId] INT NOT NULL,
    [Name] NVARCHAR(255) NOT NULL,
    [Price] DECIMAL(18,2) NOT NULL,
    [ProductArtUrl] NVARCHAR(1024) NULL
);
GO

