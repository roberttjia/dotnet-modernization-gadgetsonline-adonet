CREATE USER [appuser] FOR LOGIN [appuser] WITH DEFAULT_SCHEMA = [dbo];
GO

GRANT CONNECT TO [appuser];
GO

